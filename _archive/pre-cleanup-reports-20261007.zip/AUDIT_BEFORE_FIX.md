# Architecture Audit & Root Cause Analysis (Before Fix)

## 1. Architecture Flow
**Question → Orchestrator (`main.py/api_query_document`)**
↓
**Query Routing (`structured_query.py/classify_query`)**
- Routes to `MODEL_QA` (3D viewer) or `DOCUMENT_QA` based on basic keyword matching.
↓
**Query Parsing (`structured_query.py/robust_parse_query`)**
- Uses regex to extract `towers` (e.g., "Tower 6") and `levels` (e.g., "Level 02").
- Matches fields against a hardcoded `fields_def` dictionary.
- Identifies calculations (sum, max, etc.) and filters.
- **CRITICAL FLAW:** Limits fields to 2 (`found_fields[:2]`).
- **CRITICAL FLAW:** Returns `None` if the field isn't in the hardcoded `fields_def`.
↓
**Deterministic Lookup (`structured_query.py/execute_structured_query`)**
- Queries SQLite `structured_records`.
- Handles calculations explicitly in Python.
- Returns `SUCCESS`, `NOT_FOUND`, `AMBIGUOUS`.
↓
**RAG Fallback (`main.py/retrieve_context`)**
- Triggered if Parser returns `None` or Router chooses semantic path.
- Queries FAISS + BM25, reranks.
- **CRITICAL FLAW:** ALWAYS returns `SUCCESS` internally as long as chunks are returned, delegating NOT_FOUND responsibility entirely to the LLM.
↓
**LLM Formatting / Answering**
- Qwen2.5:32b formats the final text based on structured provenance or raw RAG text.

## 2. Current Failure Points (Phase 13 Forensic Data)

| Category | Passed | Failed | Primary Failure Reason |
|---|---|---|---|
| Unit Matrix | 0 | 64 | Field not in hardcoded whitelist → fallback to RAG → failure |
| Multi-Field | 10 | 10 | Hardcoded `found_fields[:2]` truncation |
| Not Found | 5 | 10 | RAG lacks evidence sufficiency check → LLM guessing / generic responses |

### Root Cause 1: Hardcoded Field Registry
- **File:** `intelligence/structured_query.py` -> `robust_parse_query`
- **Issue:** The parser only knows ~7 fields (GFA, GA, NISA, NSA, BUA, Balconies, Efficiency). It ignores all unit fields (1 Bed-A, 2 Bed-B, etc.), TOS, TOPR, and parking fields.
- **Fix:** Query `sqlite3` `structured_records` to dynamically build the `fields_def` dictionary at runtime (or cache it).

### Root Cause 2: Multi-Field Truncation
- **File:** `intelligence/structured_query.py` -> `robust_parse_query`
- **Issue:** `return {..., "fields": found_fields[:2], ...}` artificially limits queries to 2 fields.
- **Fix:** Remove `[:2]`. Update `execute_structured_query` to handle N fields gracefully, returning explicitly which ones were found and which were missing.

### Root Cause 3: NOT_FOUND Handling in RAG
- **File:** `intelligence/structured_query.py` -> `query_document` (RAG fallback block)
- **Issue:** If the query falls back to RAG, the system blindly passes the retrieved chunks to the LLM with `status="SUCCESS"`.
- **Fix:** Implement an Evidence Sufficiency Verification step before the LLM. If the retrieved chunks do not sufficiently address the entities/intent of the query, explicitly set `status="NOT_FOUND"` before asking the LLM to formulate an answer.

## 3. Recommended Minimal Fixes
1. **Dynamic Schema Discovery:** Introduce `db.get_dynamic_fields(project_id)` to extract all unique fields from `structured_records` and inject them into `robust_parse_query()`.
2. **Remove Truncation:** Remove `found_fields[:2]` and update the multi-field difference/percentage logic to safely handle N-field requests.
3. **Structured NOT_FOUND Enforcement:** If a query specifically asks for numerical/document facts but is completely unanswerable via structured records or drawing evidence, and RAG semantic score is too low, intercept and return `NOT_FOUND` deterministically.
4. **Evidence Object:** Refactor `format_provenance` to adhere to the requested strict Evidence Object contract.
