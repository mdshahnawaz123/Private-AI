# C3045 AMENITIES AREA BREAKDOWN — FORENSIC ROOT-CAUSE AUDIT

## 1. User Question
"AMENITIES AREA BREAKDOWN"

## 2. Project
C3045 (Resolved to `C3045 - Expo Valley Views`)

## 3. Source Document
`260610_C3045_2VA_PROJECT DATA SHEET - STAGE 4.pdf`

## 4. Source Page
Page 1

## 5. Complete Source Table
```text
| AMENITIES AREA BREAKDOWN |  |  |  |  |  |  |
| ITEM |  | % | INCL. OUTDOOR |  | EXCL. OUTDOOR |  |
|  |  |  | SQ.M. | SQ.FT. | SQ.M. | SQ.FT. |
| 1 | Multipurpose Hall | 16.26% | 221.00 | 2,378.82 | 221.00 | 2,378.82 |
| 2 | Indoor Games Room | 5.12% | 69.55 | 748.63 | 69.55 | 748.63 |
| 3 | Kids Club, Play area & Toilets | 27.80% | 377.83 | 4,066.92 | 377.83 | 4,066.92 |
| 4 | Main Gym | 25.63% | 348.39 | 3,750.04 | 348.39 | 3,750.04 |
| 5 | Sattelite Gym 01 | 11.27% | 153.19 | 1,648.92 | 153.19 | 1,648.92 |
| 6 | Sattelite Gym 02 | 8.31% | 112.88 | 1,215.03 | 112.88 | 1,215.03 |
| 7 | Prayer Rooms | 5.61% | 76.25 | 820.75 | 76.25 | 820.75 |
| TOTAL |  | 100% | 1,359.09 | 14,629.11 | 1,359.09 | 14,629.11 |
```

## 6. Number of Source Records
7 amenity records (plus 1 total row = 8 records)

## 7. Number of Extracted Records
7 amenity records were successfully read from the PDF by the raw text/table extractor (visible in `.extracted.txt`).

## 8. Number of Database Records
**0** structured records. The insertion logic actively discarded the entire table.

## 9. Number Returned by Query
0 structured records. (Fell back to Semantic RAG).

## 10. Number Passed to Evidence Layer
4 records. 
*RAG FAISS chunking split the table after row 4 at the 800-character limit. The first chunk contained the header "AMENITIES AREA BREAKDOWN", scoring high. The second chunk contained rows 5-7 but lacked the word "Amenities", so it failed to retrieve in the top k.*

## 11. Number Passed to Qwen
4 records (inside the single retrieved FAISS chunk).

## 12. Number Shown in Final Answer
4 records. Qwen perfectly formatted exactly what it received.

## 13. First Incorrect Stage
Structured Database Insertion. (The table was skipped and never became a `StructuredRecord`).

## 14. Exact File
`knowledge/extraction.py`

## 15. Exact Function
`index_structured_tables`

## 16. Exact Logic Causing Data Loss
The parser is strictly hardcoded to only insert tables that contain the columns `LEVEL` and `GFA`, and discards any row that does not contain a `TOWER` or `LEVEL`:
```python
# Lines 504-505
if any('LEVEL' in str(cell).upper() for cell in row if cell) and \
   any('GFA' in str(cell).upper() for cell in row if cell):
    header_row_idx = i

# Line 509
if header_row_idx == -1: continue

# Line 528
if not tower_val or not level_val.upper().startswith('LEVEL'): continue
```
Because the Amenities table lacks these specific architectural headers, it is dropped entirely.

## 17. Root Cause Classification
**B. STRUCTURED_DATABASE_FAILURE** 
(Specifically, a failure in the structured data ingestion pipeline that drops valid tables before they reach SQLite, forcing a fallback to RAG which then suffers from arbitrary chunk-boundary truncation).

## 18. Recommended Minimal Fix
1. Remove the strict hardcoded requirement for `LEVEL` and `GFA` headers in `index_structured_tables`.
2. Implement a generalized header detection that identifies the first row containing categorical/text data on the left and numeric data on the right (or allow tables with row keys like "Multipurpose Hall").
3. Use a generalized entity assignment: if a row does not have a `TOWER` or `LEVEL`, assign the entity to a generic row key (e.g., `entity = "Multipurpose Hall"`, `field = "SQ.M. EXCL. OUTDOOR"`, `value = 221.00`).
4. Insert these generalized key-value pairs into `structured_records` so they can be queried deterministically by the updated `execute_structured_query` engine.
