# Phase 7 (Iteration 2): Deterministic Native Extraction Report

## 1. Root Cause Found
The root cause of the "Tower 6 shifted columns" problem was conclusively identified. 
PyMuPDF (`t.extract()`) itself was **not** actually garbling Tower 6. Instead, PyMuPDF's layout engine correctly combined multiple vertical schedules (Tower 4, Tower 5, Tower 6) from a single PDF page into a single `Table` block, perfectly preserving the grid. 

However, the previous heuristic (which relied on `extract_tables_geometry` converting the PyMuPDF native table object into a Markdown string using pipes) completely distorted this structure. The Markdown formatter naively squashed columns and introduced empty cells. Furthermore, because multiple towers were in the same `Table` block, the previous entity-mapping heuristic applied the single title (e.g. `TOWER 4`) to all rows underneath, effectively masking Tower 6 data under Tower 4, or collapsing the label into `TOWER L`.

## 2. Files Modified
- `services/pipeline.py`

## 3. Functions Modified
- `process_document_pipeline` (Inside the Phase 7 NATIVE TABLE EXTRACTION block).

## 4. Exact Deterministic Normalization Logic Implemented
The native extraction logic has been rewritten to completely bypass the lossy Markdown conversion layer. It now directly operates on the native `fitz.Table.extract()` 2D grid:
1. **Dynamic Header Identification**: It reliably locates the header row by counting structural text labels across columns (bypassing multi-line title rows).
2. **Column Registration**: It dynamically identifies the primary `row_label` column (e.g. where "LEVEL" or "AREA" sits), avoiding fixed indexes.
3. **Dynamic Entity Sub-Contexts**: As it iterates down the data rows, it watches for title break rows (e.g. `['', '', '', 'TOWER 6', ...]`). When found, it dynamically updates the `current_entity_prefix`, allowing a single PyMuPDF `Table` object to span Tower 4, Tower 5, and Tower 6 without misattributing entities.
4. **Deterministic Assignment**: It strictly zips the remaining numeric values against the identified `header` column. 
5. **Deduplication**: Strict in-memory deduplication `(project, doc, page, entity, field)` protects against duplicate garbled labels.

## 5. Before/After Example of Tower 6 Table

**BEFORE (Markdown Parser Heuristics):**
```json
{
  "entity": "TOWER 4 LEVEL 02",  // Masked by top-of-table title
  "row_label": "LEVEL 02",
  "field": "Floor GFA",
  "raw_value": "2407"
}
```
Or (due to horizontal header shifting in MD):
```json
{
  "entity": "TOWER L",
  "row_label": "L",
  "field": "EVEL 02",
  "raw_value": "2407"
}
```

**AFTER (Deterministic Grid Parsing):**
```json
{
  "entity": "TOWER 6 LEVEL 02",
  "row_label": "LEVEL 02",
  "field": "Floor GFA (sqm)",
  "raw_value": "2,407"
}
```

## 6. C3085 Regression Results
A clean, end-to-end regression test was executed. All expected metrics were deterministically mapped and assigned accurately. The test accurately identified values across all complex multi-table pages.

## 7. Actual SQLite Values Verified
The following rows were manually verified from the actual `structured_records` table using direct SQLite queries immediately after ingestion:

- **T6 L02**: `('TOWER 6 LEVEL 02', 'Floor GFA (sqm)', '2,407', 2407.0)`
- **T7 L02**: `('TOWER 7 LEVEL 02', 'Floor GFA (sqm)', '2,054', 2054.0)`
- **T8 L02**: `('TOWER 8 LEVEL 02', 'Floor GFA (sqm)', '3,229', 3229.0)`
- **GF Podium**: `('GROUND FLOOR & BASEMENT GF PODIUM', 'Floor GFA (sqm)', '10,703', 10703.0)`
- **Basement**: `('GROUND FLOOR & BASEMENT BASEMENT', 'Floor GFA (sqm)', '1,710', 1710.0)`
- **Grand Total**: `('GROUND FLOOR & BASEMENT TOTAL', 'Floor GFA (sqm)', '12,413', 12413.0)`
- **Parking Required**: `('PARKING GRAND TOTAL REQUIRED', 'NORMAL', '1894', 1894.0)`
- **Parking Achieved**: `('PARKING GRAND TOTAL ACHIEVED', 'NORMAL', '1935', 1935.0)`

## 8. Number of StructuredRecords Created
- **Total Native Records**: 2,631

## 9. Duplicate Count
- **Duplicates Detected**: 0 (The deduplication set successfully prevented duplicate inserts from ambiguous structural fragments).

## 10. Ambiguous/Unresolved Count
- **High Confidence**: 2,439
- **Ambiguous Confidence**: 192 (Fragments containing non-numeric data in numeric columns correctly marked as `AMBIGUOUS`).

## 11. Was Qwen Required?
**NO**. Qwen was completely bypassed for these native tables. The values were successfully resolved, mapped, and structured entirely through deterministic logic *before* any LLM invocation.

## 12. Remaining Limitations
Because the deterministic extraction aggressively filters and parses only what PyMuPDF recognizes as native tables, tables embedded as pure image layers (e.g. `p1_1.jpeg`) still require the Vision fallback model. Consequently, the document's overall status correctly evaluates to `PARTIAL` because these embedded tables trigger visual fallback pathways, preserving the existing completeness gate.
