# OPENCOMPANY AI — FIX PRIORITY

Based on the forensic stress test and deep architectural trace, the following fixes must be implemented in exact order to repair the pipeline without rewriting the core architecture.

### FIX #1: INTEGRATE QWEN2.5-VL-7B INTO INGESTION PIPELINE (STRUCTURED_EXTRACTION)
**Severity: CRITICAL (Blocks all structural queries)**
**Target:** `services/pipeline.py` or `knowledge/extraction.py`
**Action:** The current OCR/Layout pipeline (PaddleOCR/Tesseract) fails on ETABS tables (C3103 Pages 28-30). Qwen2.5-VL-7B must be conditionally escalated during the `DOCUMENT_INGESTION` phase to extract these tables into structured formats. This output must then be cleanly saved to the `structured_records` SQLite table. *Do not rewrite the ingestion pipeline; simply add Qwen2.5-VL as the ultimate fallback for table extraction.*

### FIX #2: ENHANCE THE EVIDENCE GATE FOR ADVERSARIAL QUERIES
**Severity: HIGH**
**Target:** `intelligence/structured_query.py` (`robust_parse_query` & `execute_structured_query`)
**Action:** The query parser expects perfect matches for entities like "Left Part Y". If the database has minor OCR deviations, the SQL query returns empty. Introduce semantic fuzziness or secondary vector-based lookup in the `EVIDENCE_GATE` so the `FINAL_MODEL` is provided with the closest matching rows if an exact string match fails. 

### FIX #3: IMPLEMENT CROSS-PAGE REASONING CHUNKS
**Severity: MEDIUM**
**Target:** `knowledge/extraction.py` (RAG Indexing)
**Action:** Multi-condition calculations often require data spanning multiple pages. The current RAG chunking can cut off table context. Ensure that tabular data processed by Qwen2.5-VL is stored cohesively so the context window for the `FINAL_MODEL` contains complete table semantics.

### FIX #4: ISOLATE CALCULATIONS FROM REPORTED VALUES
**Severity: LOW**
**Target:** `FINAL_MODEL` Prompting
**Action:** When asked to "distinguish reported values from calculated values," the model needs explicit instructions in the `call_qwen_func` system prompt to state which values were retrieved from `provenance` vs. derived computationally.

---
**Summary Protocol:**
DO NOT create duplicate databases or duplicate RAG engines. Fixes must be injected *directly* into the existing stages identified above, strictly adhering to the OpenCompany architecture.
