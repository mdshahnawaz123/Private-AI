# Expo Design AI ("OPENCOMPANY") — Independent Production-Readiness Audit

**Scope:** `C:\3EH\ExpoDesignAI - Copy`, the Documents Engine (ingestion → extraction → indexing → retrieval → answer generation) and its supporting infrastructure (auth, config, database, deployment). The 3D/coordinate viewer work is explicitly out of scope for this pass, per instruction.

**Method:** Every finding below was verified live against the actual files on disk this session (`git status`, `git diff --stat`, direct greps and file reads), not taken from the ~15 prior audit reports already sitting in the repo (`ARCHITECTURE_AUDIT_REPORT.md`, `MASTER_ARCHITECTURE_ASSESSMENT.md`, `AUDIT_REPORT.*`, `OPENCOMPANY_AI_FORENSIC_STRESS_TEST_REPORT.md`, etc.). Those are **not relied on** here — several of their claims are already stale (see Finding 3).

**Bottom line:** the application logic itself (auth, config, the recent FK fix) is more solid than the file clutter suggests. The actual blocker to calling this "production ready" is process, not code: there is no reliable record of what is currently running, and the development workflow actively works against having one.

---

## Severity key
🔴 Critical — blocks any credible "production ready" claim. 🟠 High — must fix before real users depend on this. 🟡 Medium — real but not urgent. 🟢 Low / informational.

---

## 🔴 Finding 1 — The working copy and git history have diverged by nearly the whole codebase

```
21 tracked files modified, uncommitted      (main.py, db.py, auth.py, config.py, extract.py,
                                              vision.py, local_chat.py, local_embed.py,
                                              services/ingestion.py, services/pipeline.py,
                                              engines/*, worker/tasks.py, Dockerfile,
                                              docker-compose.yml, ui/*, ...)
226 untracked files (new, never committed)
main.py diff vs last commit: 4265 insertions / 3824 deletions  — i.e. essentially
                              the entire 4265-line file has been rewritten since
                              the last commit (dffd1b1, "Completely remove all
                              qwen2.5vl:32b...")
Last commit: Oct 5. Newest patch script on disk: Oct 6, 10:10am.
```

What this means concretely: **if this machine's disk were lost right now, the recoverable state from git would be the main.py from before the most recent round of fixes — not what is actually running.** There is no tag, branch, or commit anywhere that matches the current working tree. Nobody (including a future audit) can answer "what changed between last Tuesday and today" from git, because the changes were never committed — only applied to disk via scripts.

This is the root issue underneath almost every other finding in this report. Everything else is a symptom.

**Fix:** commit the current working tree in logical chunks (not one giant commit) before anything else happens to this codebase. Until that's done, every hour of work carries disk-loss risk with zero recovery path.

---

## 🔴 Finding 2 — The actual development workflow is "write a script that edits the file," not "edit the file"

58 `patch_*.py` / `fix_*.py` scripts in the repo root, 5 of which directly mutate `main.py`. These are not legacy cruft — the newest ones are from **this week** (`fix_duplicates.py` Oct 6 07:38, `patch_vision.py` Oct 6 07:46, `patch_query.py`/`patch_query2.py`/`patch_query3.py` Oct 6 09:57–10:10). Alongside them, 37 timestamped `.bak-<date>-<label>` files — the project's own ad-hoc backup convention, used *because* git isn't being used as the backup mechanism.

This pattern is why Finding 1 exists: a one-off Python script that does a string replacement into `main.py` and writes a `.bak` file is a *substitute* for `git commit` + `git diff`, and a much weaker one — it has no history, no diff review, no way to bisect which patch introduced a regression, and (as seen with `patch_query.py` → `patch_query2.py` → `patch_query3.py` on the same morning) a tendency to need 2–3 follow-up patches to actually land correctly, each layering on the last with no record of why.

**Fix:** once Finding 1 is resolved, change the *working habit*, not just the state: edit files directly with normal tooling and commit each logical change. Keep `patch_*.py` scripts only for genuinely mechanical, repeatable, reviewable transformations (and commit those scripts too, with their diff, instead of running-and-discarding).

---

## 🟠 Finding 3 — Prior audit reports contain claims that are already out of date

The Data Management Roadmap (project doc, last updated Sept 30) lists as "still open, P0": *"the extractor passes the project **name** where a project **id** is expected"* in `knowledge/extraction.index_structured_tables`/`index_quantities`, causing silent FK failures.

Checking the live code: this has been fixed. There is now a `_resolve_project_id()` helper (knowledge/extraction.py:253) that accepts either an int id or a name/slug, resolves it via a DB lookup, and logs a warning (not a silent failure) if resolution fails — wired into both `index_structured_tables` and the quantities path.

This is good news on its own, but it's also the clearest evidence for why **"don't trust the existing reports"** was the right call: at least one "still broken, P0" item documented three weeks ago is actually resolved, and the only reports that would tell you that are the ones nobody re-verified. The other ~20 report files in the repo root are now of unknown reliability for the same reason — none should be treated as current status without a live re-check.

**Fix:** treat every `*_REPORT.md` / `*_AUDIT*.md` in the repo as a historical snapshot, not a status board. If a decision needs to be made against one of their claims, re-verify against the live code first (as done here).

---

## 🟠 Finding 4 — Config correctly flags its own unresolved stopgap; it's still unresolved

`config.py`: `not_found_threshold: float = 0.0  # Phase 2 FIX: 0.3 was miscalibrated... 0.0 disables the score-gate... Recalibrate later with eval data.`

This is honestly commented — it says exactly what it is and that it needs follow-up. Confirmed live: it has **not** been recalibrated. The confidence gate that's supposed to produce honest "not found" answers instead of confident-but-wrong ones is currently fully disabled. For an engineering-review tool where a wrong area/compliance figure is a real-world safety issue (the roadmap itself calls this "SAFETY CRITICAL"), shipping with this gate off is a genuine risk, not a cosmetic one.

**Fix:** this is the one item from the old roadmap that's still real. Run the eval harness that already exists (`tests/evaluation/`) with reranker on, collect the actual score distribution for relevant vs. irrelevant chunks, and set a real threshold from data — not another guess.

---

## 🟡 Finding 5 — No tracked schema migrations; alembic is present but unused

`alembic.ini` and an `alembic/` directory exist, but `alembic/versions/` is **empty** and the `alembic` CLI isn't part of the environment used to run this app. Schema evolution instead happens via one-off scripts in the repo root (`migrate_db.py`, `migrate_to_local_db.py`, `patch_db.py`, `patch_db_ann.py`, ...). SQLAlchemy models in `db.py` define the current schema, but there is no record of *how* a database created three weeks ago gets from its old schema to today's — each migration script has to be manually identified and re-run in the right order, by memory.

**Fix:** either commit to alembic for real (generate a migration for every schema change from now on) or explicitly document the manual-migration-script convention and the order they must run in. Either is fine; the current "alembic exists but is decorative" state is not.

---

## 🟡 Finding 6 — SQLite is a real ceiling for the "enterprise, scale" direction

`database_url` defaults to `sqlite:///data/expo.db`, with `check_same_thread: False` to let FastAPI's async handlers share one file. This is a reasonable choice for the system as it's actually specified elsewhere in this project (the Data Management Roadmap: one Windows workstation, one RTX 5080 GPU, `OLLAMA_MAX_LOADED_MODELS=1`, explicit sharing with AutoCAD/D5 Render on the same box) — SQLite's single-writer model is not a bottleneck when there's effectively one local LLM serving one machine's worth of work at a time anyway.

It **is** a real ceiling the moment "enterprise ready, scale" means more than one machine or genuinely concurrent multi-user writes (simultaneous uploads, simultaneous structured-table indexing, etc. from different users) — SQLite will serialize those, and `uvicorn ... --workers 1` (the Dockerfile's own CMD) serializes the API process itself too.

**This is a direction-setting decision, not a bug**, and it's worth naming explicitly rather than quietly "fixing": the system was deliberately designed and tuned (as recently as Sept 26) around a single offline workstation with a single consumer GPU. "Enterprise ready" and "single local GPU, fully offline" pull in different directions — more users needs either more GPU capacity (shared inference service, not a workstation side-process) or accepting that scale means "more projects/documents on one box," not "more concurrent users." Worth deciding explicitly before any Postgres-migration or multi-worker work starts, so engineering effort goes where the actual target is.

---

## 🟢 Finding 7 — Security fundamentals are in better shape than the file clutter suggests

Specifically checked and confirmed sound: passwords are PBKDF2-SHA256 hashed (not plaintext, not a weak/fast hash), JWTs are signed with a secret that's either operator-supplied (`EXPO_SECRET`) or randomly generated and persisted to `data/secret.key` on first run — with an explicit, commented fix already in place for the dangerous version of this (a prior hardcoded fallback secret was removed; if the secret file can't be read or written, it now falls back to a random *in-memory* secret and loudly logs the problem, rather than silently signing tokens with a publicly-known string). Token revocation works via an `auth_version` counter checked on every request. CORS is origin-restricted via env var, not wildcarded. A scan for hardcoded passwords/keys/tokens across every `.py` file in the repo (excluding test fixtures and `os.getenv(...)` calls) found none.

On the "admin/admin" credentials you mentioned: this already exists in the code exactly as described — `EXPO_ADMIN_PASSWORD` defaults to `"admin"`, seeded on first run — **and** there's already a `must_change_password()` check that forces a change when the admin account is still on that default password. So the mechanism you asked for (seed admin/admin for now, force rotation before real use) is already built. It just isn't wired up for a second non-admin seed account yet — there's no equivalent "Sh / Sh" user today; that would need `db.create_user("Sh", hash_password("Sh"), role=...)` added to the seed path, with the same forced-change treatment extended to it rather than left exempt.

**No action required on the auth *logic* itself.** The only auth-adjacent action item is Finding 2/1: make sure the current `auth.py` on disk — which already differs from the last commit — gets committed, since it's the file this report is reading as "good."

---

## 🟢 Finding 8 — A real test suite exists and is not what the clutter makes it look like

The repo root has ~70 scratch `test_*.py`/`check_*.py`/`fix_*.py` files from iterative debugging sessions. Separately, `tests/` contains a genuine, purposeful suite: 27 pytest files covering auth, atomic uploads, backup/restore, release semantics, revision notices, calculation correctness, identifier guards, durable jobs, and more — plus a dedicated `tests/evaluation/` harness (golden question sets, an eval framework, forensic ground-truth comparisons). This is a meaningfully above-average test investment for a project this size.

I could not execute this suite from this session (no Python/pytest in this sandbox's path, and the real app dependencies live in the Windows machine's own venv) — this is a tooling-access limitation of this audit, not a claim that the tests fail. **Fix:** next session with device shell access to the actual venv, run `pytest tests/ -v` for real and report pass/fail counts — don't take "a test suite exists" as equivalent to "a test suite passes." This is exactly the kind of unverified-claim gap Finding 3 warns about, so I'm flagging it rather than guessing.

`tests/evaluation/node_modules/` (a full `@thatopen/fragments`/`three.js` install, several hundred MB) is sitting on disk but correctly `.gitignore`'d and not tracked — harmless clutter, not a repo-bloat problem.

---

## 🟢 Finding 9 — Deployment packaging is reasonable for its stated scope

`Dockerfile`: non-root user, slim base image, no secrets baked in, healthcheck endpoint wired into `docker-compose.yml`. `docker-compose.yml` binds to `127.0.0.1` only and reaches Ollama via `host.docker.internal` — consistent, again, with "one offline workstation," not a public-facing service. `worker/tasks.py` deliberately keeps Celery as a thin dispatcher into an app-owned `JobQueue`, explicitly to avoid Celery inventing its own state independent of the app's data directory — a sound design choice for exactly-once, resumable document processing.

No action needed here *unless* Finding 6's direction question resolves toward multi-machine scale, in which case `127.0.0.1` binding and `--workers 1` both need revisiting together.

---

## Priority order

1. **Commit the current working tree** (Finding 1) — nothing else here is trustworthy until "what's on disk" and "what's in git" are the same thing again.
2. **Stop the patch-script-as-editing-workflow habit going forward** (Finding 2) — or at minimum, commit each patch script's effect immediately after running it.
3. **Recalibrate `not_found_threshold`** using the real eval harness that already exists (Finding 4) — this is the one safety-relevant open item.
4. **Decide the scale direction explicitly** (Finding 6) — single-workstation-more-projects vs. true multi-user — before spending effort on either SQLite migration or GPU/inference scaling.
5. Pick a migration story (Finding 5) and actually run the existing test suite from a working Python environment (Finding 8) — both are "make the existing good work verifiable," not new work.

No code was changed as part of this audit — this is read-only investigation, same operating mode as the coordinate-anchor investigation.
