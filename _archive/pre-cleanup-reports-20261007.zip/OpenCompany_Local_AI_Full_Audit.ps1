param(
    [string]$ProjectRoot = (Get-Location).Path,
    [string]$OutputDir = "$((Get-Location).Path)\OPENCOMPANY_AUDIT"
)

$ErrorActionPreference = "Continue"
New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
$Report = Join-Path $OutputDir "LOCAL_AI_FULL_AUDIT.txt"
$JsonReport = Join-Path $OutputDir "LOCAL_AI_FULL_AUDIT.json"

$results = [ordered]@{
    generated_at = (Get-Date).ToString("o")
    computer = @{}
    gpu = @()
    ollama = @{}
    models = @()
    runtimes = @{}
    ports = @()
    project = @{}
    env_keys = @()
    processes = @()
    disk = @()
}

function Add-Section($title) {
    Add-Content $Report "`r`n============================================================"
    Add-Content $Report $title
    Add-Content $Report "============================================================"
}

"OPENCOMPANY LOCAL AI - FULL READ-ONLY AUDIT" | Set-Content $Report
"Generated: $($results.generated_at)" | Add-Content $Report
"ProjectRoot: $ProjectRoot" | Add-Content $Report

Add-Section "1. WINDOWS / HARDWARE"
$os = Get-CimInstance Win32_OperatingSystem
$cs = Get-CimInstance Win32_ComputerSystem
$cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
$computer = [ordered]@{
    windows = $os.Caption
    version = $os.Version
    build = $os.BuildNumber
    manufacturer = $cs.Manufacturer
    model = $cs.Model
    ram_gb = [math]::Round($cs.TotalPhysicalMemory/1GB,2)
    cpu = $cpu.Name
    cpu_cores = $cpu.NumberOfCores
    logical_processors = $cpu.NumberOfLogicalProcessors
}
$results.computer = $computer
$computer | Format-List | Out-String | Add-Content $Report

Add-Section "2. GPU / CUDA"
$gpus = Get-CimInstance Win32_VideoController | Select-Object Name,DriverVersion,AdapterRAM
$results.gpu = @($gpus)
$gpus | Format-Table -AutoSize | Out-String | Add-Content $Report

Add-Section "3. NVIDIA-SMI"
$nvidia = Get-Command nvidia-smi -ErrorAction SilentlyContinue
if ($nvidia) {
    & nvidia-smi --query-gpu=name,driver_version,memory.total,memory.used,memory.free,utilization.gpu --format=csv,noheader 2>&1 | Tee-Object -Variable nvidiaOut | Add-Content $Report
} else {
    "nvidia-smi not found" | Add-Content $Report
}

Add-Section "4. OLLAMA"
$ollamaCmd = Get-Command ollama -ErrorAction SilentlyContinue
if ($ollamaCmd) {
    $ollamaVersion = (& ollama --version 2>&1) -join "`n"
    $ollamaList = (& ollama list 2>&1) -join "`n"
    $ollamaPs = (& ollama ps 2>&1) -join "`n"
    $results.ollama = @{
        executable = $ollamaCmd.Source
        version = $ollamaVersion
        list = $ollamaList
        ps = $ollamaPs
    }
    "Executable: $($ollamaCmd.Source)" | Add-Content $Report
    "Version:" | Add-Content $Report
    $ollamaVersion | Add-Content $Report
    "Models:" | Add-Content $Report
    $ollamaList | Add-Content $Report
    "Running models:" | Add-Content $Report
    $ollamaPs | Add-Content $Report
} else {
    "Ollama executable not found in PATH" | Add-Content $Report
}

Add-Section "5. MODEL FILES / OLLAMA DIRECTORY"
$ollamaDir = $env:OLLAMA_MODELS
if (-not $ollamaDir) {
    $ollamaDir = Join-Path $env:USERPROFILE ".ollama\models"
}
"Model directory candidate: $ollamaDir" | Add-Content $Report
if (Test-Path $ollamaDir) {
    $size = (Get-ChildItem $ollamaDir -Recurse -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum
    "Total model storage GB: $([math]::Round($size/1GB,2))" | Add-Content $Report
    Get-ChildItem $ollamaDir -Recurse -File -ErrorAction SilentlyContinue |
        Sort-Object Length -Descending |
        Select-Object -First 30 FullName,@{N="GB";E={[math]::Round($_.Length/1GB,2)}} |
        Format-Table -AutoSize | Out-String | Add-Content $Report
} else {
    "Model directory not found." | Add-Content $Report
}

Add-Section "6. PYTHON / NODE / GIT"
$cmds = @("python","python3","pip","node","npm","git")
foreach ($c in $cmds) {
    $x = Get-Command $c -ErrorAction SilentlyContinue
    if ($x) {
        "$c : $($x.Source)" | Add-Content $Report
        try { (& $c --version 2>&1) | Add-Content $Report } catch {}
    } else {
        "$c : NOT FOUND" | Add-Content $Report
    }
}

Add-Section "7. PYTHON AI PACKAGES"
if (Get-Command python -ErrorAction SilentlyContinue) {
    $pkgs = @("torch","transformers","ollama","pymupdf","pytesseract","easyocr","faiss-cpu","faiss-gpu","sentence-transformers","numpy","pandas","sqlalchemy","fastapi","uvicorn")
    foreach ($p in $pkgs) {
        $line = (& python -c "import importlib.metadata as m; print(m.version('$p'))" 2>$null)
        if ($LASTEXITCODE -eq 0) { "$p : $line" | Add-Content $Report }
        else { "$p : NOT INSTALLED" | Add-Content $Report }
    }
    "Torch CUDA check:" | Add-Content $Report
    (& python -c "import torch; print('torch=',torch.__version__); print('cuda_available=',torch.cuda.is_available()); print('cuda_version=',torch.version.cuda); print('gpu_count=',torch.cuda.device_count()); print('gpu_name=',torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'N/A')" 2>&1) | Add-Content $Report
}

Add-Section "8. IMPORTANT ENVIRONMENT KEYS (VALUES HIDDEN)"
$interesting = Get-ChildItem Env: | Where-Object {
    $_.Name -match "OLLAMA|CUDA|NVIDIA|OPENAI|QWEN|MODEL|HF_|TRANSFORMERS|TOKEN|API|FAISS"
}
foreach ($e in $interesting) {
    $results.env_keys += $e.Name
    "$($e.Name) = [HIDDEN]" | Add-Content $Report
}

Add-Section "9. LISTENING LOCAL PORTS"
$ports = Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue |
    Sort-Object LocalPort |
    Select-Object LocalAddress,LocalPort,OwningProcess
$results.ports = @($ports)
$ports | Format-Table -AutoSize | Out-String | Add-Content $Report

Add-Section "10. AI / LOCAL SERVER PROCESSES"
$proc = Get-Process -ErrorAction SilentlyContinue |
    Where-Object { $_.ProcessName -match "ollama|python|node|uvicorn|qwen|llama|vllm|text-generation|opencompany" } |
    Select-Object ProcessName,Id,@{N="RAM_MB";E={[math]::Round($_.WorkingSet64/1MB,0)}}
$results.processes = @($proc)
$proc | Format-Table -AutoSize | Out-String | Add-Content $Report

Add-Section "11. PROJECT STRUCTURE"
if (Test-Path $ProjectRoot) {
    $files = Get-ChildItem $ProjectRoot -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object { $_.FullName -notmatch "\\(\.git|node_modules|__pycache__|\.venv|venv)\\?" } |
        Select-Object FullName,Length,LastWriteTime
    $results.project = @{
        root = $ProjectRoot
        file_count = @($files).Count
    }
    "File count: $(@($files).Count)" | Add-Content $Report
    "Top-level:" | Add-Content $Report
    Get-ChildItem $ProjectRoot -Force | Select-Object Mode,Length,LastWriteTime,Name |
        Format-Table -AutoSize | Out-String | Add-Content $Report
    "Python files:" | Add-Content $Report
    $files | Where-Object {$_.FullName -match "\.py$"} |
        Sort-Object FullName | Select-Object -First 300 FullName |
        Format-Table -AutoSize | Out-String | Add-Content $Report
}

Add-Section "12. GIT STATUS"
if (Test-Path (Join-Path $ProjectRoot ".git")) {
    Push-Location $ProjectRoot
    git status --short 2>&1 | Add-Content $Report
    git log -5 --oneline 2>&1 | Add-Content $Report
    Pop-Location
} else {
    "No .git directory at project root." | Add-Content $Report
}

Add-Section "13. DISK SPACE"
Get-PSDrive -PSProvider FileSystem |
    Select-Object Name,@{N="FreeGB";E={[math]::Round($_.Free/1GB,1)}},@{N="UsedGB";E={[math]::Round($_.Used/1GB,1)}} |
    Format-Table -AutoSize | Out-String | Add-Content $Report

Add-Section "14. AUDIT INTERPRETATION"
@"
This is a READ-ONLY environment audit. It does not modify models, databases,
Ollama models, project files, or configuration.

For production readiness, separately audit:
A. Model identity/version/hash
B. Prompt/configuration
C. Vision/OCR extraction
D. StructuredRecord creation
E. SQLite records and entity/level/field mapping
F. Query parser/entity normalization
G. Deterministic calculations
H. Evidence/provenance gate
I. RAG fallback
J. Qwen final-answer synthesis
K. Error/NOT_FOUND handling
L. Performance/concurrency
M. Regression benchmark results

DO NOT paste API keys, tokens, passwords, or secret values into the report.
"@ | Add-Content $Report

$results | ConvertTo-Json -Depth 8 | Set-Content $JsonReport

Write-Host ""
Write-Host "AUDIT COMPLETE"
Write-Host "TXT : $Report"
Write-Host "JSON: $JsonReport"
