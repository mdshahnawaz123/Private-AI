# PROJECT INTELLIGENCE ARCHITECTURE MIGRATION PLAN

## 1. Existing Architecture
Currently, OpenCompany relies on a single shared global database (`data/expo.db`) for all projects, documents, structured records, extracted values, and user uploads. 
- The physical storage uses flat `.pdf_images`, `.extracted`, and chunk files within a `data/docs/<Project>` folder, meaning folder hierarchy inside the UI is mapped logically in the global DB (`Folder` table) rather than directly leveraging the physical path hierarchy on disk effectively.
- All extracted intelligence (`StructuredRecord`) lives in a single table segmented only by a `project_id` foreign key.
- RAG indexes are centrally managed, risking cross-project bleed if the `WHERE project_id` filter is ever omitted.
- Missing explicit separation of `Source`, `Evidence`, and `Finding`. The current extraction just dumps tabular entities directly into `StructuredRecord`.
- No `Relationship` graph to cross-verify discrepancies between sources (e.g. Schedule vs Document).
- No concept of `Source Authority`.

## 2. New Architecture
The new architecture divides the system into three distinct layers:
1. **Layer 1: Project Folder Structure (UI & Organization)**: Mirrors actual project hierarchy dynamically based on standard Admin disciplines (e.g. Architecture/Documents).
2. **Layer 2: Project Knowledge Database**: A completely isolated physical database `data/docs/<ProjectName>/.opencompany/project.db` for EVERY project. This becomes the primary project isolation boundary. Normal queries cannot access other projects because they don't even connect to the other databases.
3. **Layer 3: Evidence & Relationship Graph**: New structures in the project-local database explicitly separating `File`, `StructuredRecord` (Normalized data), `Evidence` (Verified finding instance), `Finding` (Derived issue/conclusion), and `Relationship` (Graph links between elements).

## 3. Migration Plan (Phased)
To ensure the transition is safe without breaking the current Phase 7 native table extraction:

### Phase 1: Local Database Schema Definition
- Create `project_db.py` holding the new SQLAlchemy schema (`ProjectFolder`, `ProjectFile`, `StructuredRecord`, `Evidence`, `Finding`, `Relationship`).
- Build a connection helper `get_project_session(project_name)` that routes DB requests dynamically to the isolated `project.db`.

### Phase 2: Safe Data Migration (Non-Destructive)
- Write a migration script that scans the existing `expo.db` global database.
- For each project (e.g., `C3085 - Expo Hills`):
  1. Initialize the new local `project.db`.
  2. Synthesize the new `ProjectFolder` structure (e.g., extracting from the old flat folder hierarchy or generating standard branches like `Architecture/Documents`).
  3. Migrate existing `Document` rows to `ProjectFile` instances under the new folder structures.
  4. Migrate all existing `StructuredRecord` entries (specifically retaining the verified Phase 7 C3085 records) into the local `StructuredRecord` table.
  5. Generate initial `Evidence` rows bound to these `StructuredRecord` values with `source_authority = "AI Extraction"` or "Native PDF".

### Phase 3: Application Routing Update
- Update retrieval loops (like `structured_query.py` or the intelligence endpoints) to point at `get_project_session(project_name)` instead of the global `SessionLocal()`.
- Update RAG index loaders to save and load FAISS vectors from `data/docs/<ProjectName>/.opencompany/rag.index` to guarantee index isolation.

### Phase 4: Verification Policy Logic
- Introduce a comparison verification loop. When the user asks to "Check X first and confirm from Y", the AI reasoning loop will perform two separate retrievals from the local DB, check the `Evidence` graph, and explicitly yield `CONFIRMED` or `SOURCE_CONFLICT`.

## Next Steps for Immediate Execution
I will write the migration script that performs Phase 1 and Phase 2. This script will physically generate `data/docs/C3085 - 3EH -Expo Hills/.opencompany/project.db` and migrate the existing 2,631 records perfectly into the new isolated architecture, proving the isolation.
