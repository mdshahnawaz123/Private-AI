# Vision/OCR Fallback Architecture Report

## 1. Current Vision/OCR Architecture
The existing architecture used a naive two-step fallback implemented inline within `services/pipeline.py`:
1. It first attempted to read image-based engineering tables using `EasyOCR`. If it could not assemble a clean tabular matrix (due to column variances or missing rows), it failed.
2. Upon failure, it manually posted the image (as base64) to `Qwen2.5-VL 7B` via an Ollama HTTP call, prompting it to generate a Markdown table.
The logic was heavily intertwined with the main pipeline structure and lacked a clean interface boundary for future extensions.

## 2. Files Inspected
- `services/pipeline.py` (Visual extraction logic was directly inline).

## 3. Files Modified
- `services/pipeline.py`: Removed the hardcoded EasyOCR/Qwen fallbacks and replaced them with a single abstract `extract_visual_table(img_path, context)` interface call.
- `benchmark_vision.py`: Created from scratch as the new testing harness.
- `services/vision_adapter.py`: Created from scratch to establish the new boundary.

## 4. Exact Adapter Created
I created the `VisionExtractor` abstract base class in `services/vision_adapter.py`. 
It exposes a clean method: `extract(img_path, page_text) -> dict`.
I implemented three concrete extractors:
- `DeepSeekOCR2Extractor`
- `EasyOCRExtractor`
- `QwenVLExtractor`

A unified wrapper function, `extract_visual_table()`, loops through these adapters in strict priority order (1. DeepSeek, 2. EasyOCR, 3. Qwen). The output strictly conforms to a standardized JSON schema preserving `engine`, `success`, `raw_text`, `confidence`, and `error`.

## 5. Existing EasyOCR/Qwen Dependencies Preserved
The exact existing logic for `EasyOCR` (including its `15px` row threshold and column variance heuristics) and `Qwen2.5-VL` (including its specific Markdown table prompt) were faithfully ported into the new adapter classes. No existing fallback behavior or constraints were altered.

## 6. DeepSeek-OCR-2 Installation Status
**NOT_INSTALLED**. 
The `DeepSeekOCR2Extractor` class immediately returns:
`{"success": False, "engine": "NOT_INSTALLED", "error": "DeepSeek-OCR-2 not installed"}` 
This cleanly bypasses the model execution while preparing the exact entry point where the implementation will eventually live.

## 7. Benchmark Harness Location
The benchmark capability is located at: `benchmark_vision.py`. It is a lightweight, decoupled CLI utility that pushes specific problematic image arrays (like `p1_1.jpeg` and `p28_3.jpeg`) through the `extract_visual_table` interface and prints the performance, success state, error strings, and structured metrics to a JSON summary. 

## 8. C3085 Native Regression Result
The C3085 native regression remains flawless. 2,631 total structured records were correctly pulled natively with 0 duplicates. Because the native logic (implemented in Phase 7 Iteration 2) takes strict precedence and completely bypasses the Vision adapter, the visual fallback reorganization safely posed zero regression risk to the working native engineering metrics.

## 9. C3103 Visual Benchmark Setup
The benchmark array includes `C3103-RPT.../p28_3.jpeg` (the specific image crop for the Torsional Irregularity Table). It is fully primed to test whether a future OCR engine successfully captures the ground-truth values (Maximum X = 1.095, Maximum Y = 1.242) natively without hallucinatory LLM reconstruction.

## 10. Remaining Issues
Currently, because DeepSeek is unavailable and EasyOCR structurally fails on these complex nested tables, the requests predictably fall through to `Qwen2.5-VL`, which occasionally hallucinates column alignments or takes a very long time. The interface currently explicitly tags all Qwen outputs as `confidence = "AMBIGUOUS"` by default, preventing unverified data from silently corrupting the database.

## 11. Next Step
To proceed with DeepSeek-OCR-2:
1. Verify system requirements (VRAM) and install the DeepSeek-OCR-2 model (via Ollama or python dependency).
2. Replace the `DeepSeekOCR2Extractor` dummy logic with the actual API/SDK invocation.
3. Run `python benchmark_vision.py` to objectively verify that DeepSeek correctly parses `p1_1.jpeg` and `p28_3.jpeg` before fully integrating it into the production extraction pipeline.
