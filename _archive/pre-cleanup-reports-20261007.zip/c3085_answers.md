**Q036. What is Tower 8 Level 02 NSA/GFA efficiency?**
85.8%

**Q051. What is Tower 4 Level 02 Floor NISA?**
2690

**Q294. Is a parking rate for 4 Bed explicitly listed?**
Yes

**Q251. What is Tower 7 Level 02 NSA if calculated as NISA plus balconies?**
1665

**Q283. For Tower 5, do the total 1-bed, 2-bed and 3-bed counts sum to the displayed total units?**
NOT_FOUND

**Q047. What is Tower 5 Level 10 Floor GFA?**
NOT_FOUND

**Q081. What is Tower 1 Level 02 Floor NISA?**
3232

**Q043. What is Tower 5 Level 02 Floor NSA?**
2393

**Q188. What is the total balcony area for Tower 8?**
NOT_FOUND

**Q107. What is the total Floor NSA for Tower 2?**
NOT_FOUND

**Q293. Is a Penthouse unit category explicitly listed?**
NOT_FOUND

**Q202. What is the GF Podium F&B area?**
NOT_FOUND

**Q301. Is the total parking achieved 1,894?**
Yes

**Q002. What stage of design is identified in the document?**
NOT_FOUND

**Q288. Is there a Level 12 area row for Tower 6?**
NOT_FOUND

**Q289. Is there a Level 12 area row for Tower 7?**
NOT_FOUND

**Q161. What is the total Floor NSA for Tower 6?**
NOT_FOUND

**Q087. What is Tower 1 Level 08 Floor GFA?**
NOT_FOUND

**Q129. What is the total Floor GFA for Tower 4?**
NOT_FOUND

**Q135. What is the NSA/GA efficiency for Tower 4?**
NOT_FOUND

**Q278. What BUA does Schedule 03 actually print as the total?**
NOT_FOUND

**Q184. How many tandem parking bays are shown for Tower 7?**
NOT_FOUND

**Q076. What is Tower 2 Level 02 NSA/GFA efficiency?**
87.1%

**Q264. What is the difference between Tower 4 Level 02 Floor NSA and Floor NISA?**
2690

**Q133. What is the total Floor NSA for Tower 4?**
NOT_FOUND

**Q234. What is the combined T06 Visitors and Surface Visitors count?**
NOT_FOUND

**Q018. What is Tower 6 Level 11 Floor BUA?**
NOT_FOUND

**Q266. What is the difference between Tower 2 Level 02 Floor NSA and Floor NISA?**
3232

**Q167. How many 3-bedroom units are shown in the total row for Tower 6?**
NOT_FOUND

**Q127. How many 3-bedroom units are shown in the total row for Tower 3?**
NOT_FOUND

**Q108. What is the total Floor BUA for Tower 2?**
NOT_FOUND

**Q063. What is Tower 3 Level 02 Floor NSA?**
3199

**Q126. How many 2-bedroom units are shown in the total row for Tower 3?**
NOT_FOUND

**Q049. What is Tower 4 Level 02 Floor GFA?**
3329

**Q022. What is Tower 7 Level 02 Balconies area?**
114

**Q309. What is T7 L2 GA?**
2111

**Q260. What is the difference between Tower 6 Level 02 Floor NSA and Floor NISA?**
1940

**Q299. Is the Basement retail area 2,044 sqm?**
Yes

**Q201. What is the GF Podium Retail area?**
1,058

**Q247. What is the F&B GFA shown in the ground floor/basement section?**
NOT_FOUND

**Q254. What is Tower 4 Level 02 NSA if calculated as NISA plus balconies?**
2690

**Q158. What is the total Floor GA for Tower 6?**
NOT_FOUND

**Q233. What is the East Parking count?**
NOT_FOUND

**Q321. What is T4 L2 BUA?**
3601

**Q224. What parking rate is shown for 2 Bed at a Standard Bay?**
NOT_FOUND

**Q078. What is Tower 2 Level 09 Floor BUA?**
NOT_FOUND

**Q316. What is T2 L2 GFA?**
3952

**Q333. What is the target 2-bedroom unit mix percentage shown in Schedule 05?**
NOT_FOUND

**Q258. What is the difference between Tower 6 Level 02 Floor BUA and Floor GFA?**
2407

**Q275. What is the achieved-to-required parking ratio?**
NOT_FOUND

**Q095. What is the NSA/GA efficiency for Tower 1?**
NOT_FOUND

**Q270. What is Tower 7 Level 02 NSA/GA when calculated from 1,779 and 2,111?**
84.3%

**Q231. What is the T06 Visitors count?**
NOT_FOUND

**Q029. What is Tower 8 Level 02 Floor GFA?**
3229

**Q165. How many 1-bedroom units are shown in the total row for Tower 6?**
NOT_FOUND

**Q284. For Tower 6, do the total 1-bed, 2-bed and 3-bed counts sum to the displayed total units?**
NOT_FOUND

**Q229. How many Normal Tandem Pod parking spaces are shown?**
NOT_FOUND

**Q306. What is the net saleable area for Tower 6 Level 2?**
NOT_FOUND

**Q172. What is the total Floor GA for Tower 7?**
NOT_FOUND

**Q021. What is Tower 7 Level 02 Floor NISA?**
1665

**Q024. What is Tower 7 Level 02 Floor BUA?**
2261

**Q148. What is the total Floor BUA for Tower 5?**
NOT_FOUND

**Q241. What is the overall achieved 3-bedroom unit mix percentage?**
NOT_FOUND

**Q220. What is the future EV parking count shown?**
NOT_FOUND

**Q157. What is the total Floor GFA for Tower 6?**
NOT_FOUND

**Q325. Which schedule contains parking rates and count?**
NOT_FOUND

**Q088. What is Tower 1 Level 08 Floor BUA?**
NOT_FOUND

**Q313. What is T8 L2 BUA?**
3467

**Q263. What is the difference between Tower 5 Level 02 Floor NSA and Floor NISA?**
2247

**Q074. What is Tower 2 Level 02 Floor BUA?**
4253

**Q298. Is Floor NSA calculated as NISA minus balconies?**
NOT_FOUND

**Q035. What is Tower 8 Level 02 NSA/GA efficiency?**
85.6%

**Q162. What is the total Floor BUA for Tower 6?**
NOT_FOUND

**Q252. What is Tower 8 Level 02 NSA if calculated as NISA plus balconies?**
2602

**Q282. For Tower 4, do the total 1-bed, 2-bed and 3-bed counts sum to the displayed total units?**
NOT_FOUND

**Q141. How many standard parking bays are shown for Tower 4?**
NOT_FOUND

**Q086. What is Tower 1 Level 02 NSA/GFA efficiency?**
86.1%

**Q072. What is Tower 2 Level 02 Balconies area?**
210

**Q164. What is the NSA/GFA efficiency for Tower 6?**
NOT_FOUND

**Q199. What is the GF Podium Floor GFA?**
NOT_FOUND

**Q080. What is Tower 1 Level 02 Floor GA?**
4003

**Q079. What is Tower 1 Level 02 Floor GFA?**
3993

**Q115. How many standard parking bays are shown for Tower 2?**
NOT_FOUND

**Q300. Is the Basement BUA 59,512 sqm?**
Yes

**Q106. What is the total balcony area for Tower 2?**
NOT_FOUND

**Q064. What is Tower 3 Level 02 Floor BUA?**
3974

**Q142. How many tandem parking bays are shown for Tower 4?**
NOT_FOUND

**Q119. What is the total Floor NISA for Tower 3?**
NOT_FOUND

**Q011. What is Tower 6 Level 02 Floor NISA?**
1940

**Q025. What is Tower 7 Level 02 NSA/GA efficiency?**
84.3%

**Q085. What is Tower 1 Level 02 NSA/GA efficiency?**
85.9%

**Q009. What is Tower 6 Level 02 Floor GFA?**
2407

**Q130. What is the total Floor GA for Tower 4?**
NOT_FOUND

**Q150. What is the NSA/GFA efficiency for Tower 5?**
NOT_FOUND

**Q096. What is the NSA/GFA efficiency for Tower 1?**
NOT_FOUND

**Q246. What is the retail GFA shown in the ground floor/basement section?**
NOT_FOUND

**Q057. What is Tower 4 Level 10 Floor GFA?**
NOT_FOUND

**Q139. How many 3-bedroom units are shown in the total row for Tower 4?**
NOT_FOUND

**Q238. Are the displayed 1 Bed, 2 Bed and 3 Bed parking rates different from each other?**
NOT_FOUND

**Q211. What is the total Floor GFA for GF Podium plus Basement?**
NOT_FOUND

**Q110. What is the NSA/GFA efficiency for Tower 2?**
NOT_FOUND

**Q230. How many Normal Tandem Pod spaces are shown as achieved/required?**
NOT_FOUND

**Q030. What is Tower 8 Level 02 Floor GA?**
3238

**Q034. What is Tower 8 Level 02 Floor BUA?**
3467

**Q111. How many 1-bedroom units are shown in the total row for Tower 2?**
NOT_FOUND

**Q286. For Tower 8, do the total 1-bed, 2-bed and 3-bed counts sum to the displayed total units?**
NOT_FOUND

**Q334. What is the target 3-bedroom unit mix percentage shown in Schedule 05?**
NOT_FOUND

**Q186. What is the total Floor GA for Tower 8?**
NOT_FOUND

**Q212. What is the total Floor BUA for GF Podium plus Basement?**
NOT_FOUND

**Q039. What is Tower 5 Level 02 Floor GFA?**
2772

**Q181. How many 3-bedroom units are shown in the total row for Tower 7?**
NOT_FOUND

**Q151. How many 1-bedroom units are shown in the total row for Tower 5?**
NOT_FOUND

**Q329. What two efficiency metrics are shown for individual towers?**
NOT_FOUND

**Q324. Which schedule contains the GF Podium and Basement area breakdown?**
NOT_FOUND

**Q180. How many 2-bedroom units are shown in the total row for Tower 7?**
NOT_FOUND

**Q145. What is the total Floor NISA for Tower 5?**
NOT_FOUND

**Q131. What is the total Floor NISA for Tower 4?**
NOT_FOUND

**Q257. What is Tower 1 Level 02 NSA if calculated as NISA plus balconies?**
3232

**Q196. What is the total number of residential units for Tower 8?**
NOT_FOUND

**Q050. What is Tower 4 Level 02 Floor GA?**
3392

**Q291. Is a 4-bedroom unit category listed in the unit matrix?**
NOT_FOUND

**Q054. What is Tower 4 Level 02 Floor BUA?**
3601

**Q285. For Tower 7, do the total 1-bed, 2-bed and 3-bed counts sum to the displayed total units?**
NOT_FOUND

**Q232. What is the Surface Visitors count?**
NOT_FOUND

**Q075. What is Tower 2 Level 02 NSA/GA efficiency?**
86.0%

**Q205. What is the Basement Floor GFA?**
NOT_FOUND

**Q003. What is the document title?**
NOT_FOUND

**Q155. How many standard parking bays are shown for Tower 5?**
NOT_FOUND

**Q297. Does the schedule state that Tower 6 Level 02 Floor BUA is 2,616 sqm?**
2615

**Q259. What is the difference between Tower 6 Level 02 Floor GA and Floor GFA?**
2407

**Q121. What is the total Floor NSA for Tower 3?**
NOT_FOUND

**Q083. What is Tower 1 Level 02 Floor NSA?**
3438

**Q311. What is T7 L2 NSA?**
1779

**Q012. What is Tower 6 Level 02 Balconies area?**
131

**Q198. How many tandem parking bays are shown for Tower 8?**
NOT_FOUND

**Q239. What is the overall achieved 1-bedroom unit mix percentage?**
NOT_FOUND

**Q134. What is the total Floor BUA for Tower 4?**
NOT_FOUND

**Q243. What is the overall efficiency APT NSA/GA?**
NOT_FOUND

**Q308. What is T7 L2 GFA?**
2054

**Q112. How many 2-bedroom units are shown in the total row for Tower 2?**
NOT_FOUND

**Q179. How many 1-bedroom units are shown in the total row for Tower 7?**
NOT_FOUND

**Q146. What is the total balcony area for Tower 5?**
NOT_FOUND

**Q226. What is the grand total parking required?**
NOT_FOUND

**Q098. How many 2-bedroom units are shown in the total row for Tower 1?**
NOT_FOUND

**Q007. What is the drawing/document reference shown on the cover?**
NOT_FOUND

**Q274. What is the arithmetic difference between displayed parking achieved and required?**
NOT_FOUND

**Q195. How many 3-bedroom units are shown in the total row for Tower 8?**
NOT_FOUND

**Q273. What is Tower 8 Level 02 NSA/GFA when calculated from 2,772 and 3,229?**
85.8%

**Q255. What is Tower 3 Level 02 NSA if calculated as NISA plus balconies?**
3002

**Q191. What is the NSA/GA efficiency for Tower 8?**
NOT_FOUND

**Q276. What is the total GFA from Schedule 03 if GF Podium and Basement GFA are added?**
NOT_FOUND

**Q154. What is the total number of residential units for Tower 5?**
NOT_FOUND

**Q207. Does the Basement have a Retail area listed?**
NOT_FOUND

**Q279. Is there a 1 sqm discrepancy between the BUA arithmetic sum and the printed total?**
NOT_FOUND

**Q295. Is Tower 6 Level 02 Floor NIA explicitly listed as a metric?**
NOT_FOUND

**Q227. What is the grand total parking achieved?**
NOT_FOUND

**Q237. What is the parking surplus percentage over required?**
NOT_FOUND

**Q147. What is the total Floor NSA for Tower 5?**
NOT_FOUND

**Q203. What is the GF Podium Supermarket area?**
NOT_FOUND

**Q138. How many 2-bedroom units are shown in the total row for Tower 4?**
NOT_FOUND

**Q280. For Tower 1, do the total 1-bed, 2-bed and 3-bed counts sum to the displayed total units?**
NOT_FOUND

**Q061. What is Tower 3 Level 02 Floor NISA?**
3002

**Q185. What is the total Floor GFA for Tower 8?**
NOT_FOUND

**Q105. What is the total Floor NISA for Tower 2?**
NOT_FOUND

**Q182. What is the total number of residential units for Tower 7?**
NOT_FOUND

**Q331. What two parking bay types are summarized for towers?**
NOT_FOUND

**Q073. What is Tower 2 Level 02 Floor NSA?**
3442

**Q005. What is the KEO role/services stated on the cover?**
NOT_FOUND

**Q210. Does the Basement have a Nursery area listed?**
NOT_FOUND

**Q281. For Tower 2, do the total 1-bed, 2-bed and 3-bed counts sum to the displayed total units?**
NOT_FOUND

**Q144. What is the total Floor GA for Tower 5?**
NOT_FOUND

**Q222. What is the future EV count for the second listed category?**
NOT_FOUND

**Q077. What is Tower 2 Level 09 Floor GFA?**
NOT_FOUND

**Q006. What is the RFS number?**
NOT_FOUND

**Q163. What is the NSA/GA efficiency for Tower 6?**
NOT_FOUND

**Q219. What is the current EV parking count shown?**
NOT_FOUND

**Q100. What is the total number of residential units for Tower 1?**
NOT_FOUND

**Q173. What is the total Floor NISA for Tower 7?**
NOT_FOUND

**Q117. What is the total Floor GFA for Tower 3?**
NOT_FOUND

**Q048. What is Tower 5 Level 10 Floor BUA?**
NOT_FOUND

**Q204. What is the GF Podium Nursery area?**
NOT_FOUND

**Q062. What is Tower 3 Level 02 Balconies area?**
197

**Q032. What is Tower 8 Level 02 Balconies area?**
170

**Q031. What is Tower 8 Level 02 Floor NISA?**
2602

**Q120. What is the total balcony area for Tower 3?**
NOT_FOUND

**Q123. What is the NSA/GA efficiency for Tower 3?**
NOT_FOUND

**Q104. What is the total Floor GA for Tower 2?**
NOT_FOUND

**Q015. What is Tower 6 Level 02 NSA/GA efficiency?**
84.7%

**Q318. What is T3 L2 GFA?**
3687

**Q128. What is the total number of residential units for Tower 3?**
NOT_FOUND

**Q235. How many more parking spaces are achieved than required?**
NOT_FOUND

**Q250. What is Tower 6 Level 02 NSA if calculated as NISA plus balconies?**
1940

**Q223. What parking rate is shown for 1 Bed at a Standard Bay?**
NOT_FOUND

**Q261. What is the difference between Tower 7 Level 02 Floor NSA and Floor NISA?**
1665

**Q269. What is Tower 6 Level 02 NSA/GFA when calculated from 2,071 and 2,407?**
86.0%

**Q089. What is the total Floor GFA for Tower 1?**
NOT_FOUND

**Q183. How many standard parking bays are shown for Tower 7?**
NOT_FOUND

**Q094. What is the total Floor BUA for Tower 1?**
NOT_FOUND

**Q221. What is the current EV count for the second listed category?**
NOT_FOUND

**Q330. What three bedroom groupings are used in the unit matrix?**
NOT_FOUND

**Q059. What is Tower 3 Level 02 Floor GFA?**
3687

**Q193. How many 1-bedroom units are shown in the total row for Tower 8?**
NOT_FOUND

**Q136. What is the NSA/GFA efficiency for Tower 4?**
NOT_FOUND

**Q122. What is the total Floor BUA for Tower 3?**
NOT_FOUND

**Q317. What is T2 L2 BUA?**
4253

**Q206. What is the Basement Floor BUA?**
NOT_FOUND

**Q245. What is the total Basement GFA shown in the grand total section?**
NOT_FOUND

**Q314. What is T1 L2 GFA?**
3993

**Q218. Is the total BUA equal to GF Podium BUA plus Basement BUA?**
NOT_FOUND

**Q326. Which schedule contains the grand total area schedule and unit matrix?**
NOT_FOUND

**Q319. What is T3 L2 BUA?**
3974

**Q097. How many 1-bedroom units are shown in the total row for Tower 1?**
NOT_FOUND

**Q060. What is Tower 3 Level 02 Floor GA?**
3739

**Q056. What is Tower 4 Level 02 NSA/GFA efficiency?**
86.2%

**Q249. What is the supermarket GFA shown in the ground floor/basement section?**
NOT_FOUND

**Q315. What is T1 L2 BUA?**
4282

**Q042. What is Tower 5 Level 02 Balconies area?**
146

**Q017. What is Tower 6 Level 11 Floor GFA?**
NOT_FOUND

**Q008. How many pages are in the uploaded area schedule?**
NOT_FOUND

**Q046. What is Tower 5 Level 02 NSA/GFA efficiency?**
86.3%

**Q118. What is the total Floor GA for Tower 3?**
NOT_FOUND

**Q109. What is the NSA/GA efficiency for Tower 2?**
NOT_FOUND

**Q090. What is the total Floor GA for Tower 1?**
NOT_FOUND

**Q304. How much NISA does Tower 6 have on Level 2?**
NOT_FOUND

**Q177. What is the NSA/GA efficiency for Tower 7?**
NOT_FOUND

**Q192. What is the NSA/GFA efficiency for Tower 8?**
NOT_FOUND

**Q156. How many tandem parking bays are shown for Tower 5?**
NOT_FOUND

**Q033. What is Tower 8 Level 02 Floor NSA?**
2772

**Q020. What is Tower 7 Level 02 Floor GA?**
2111

**Q116. How many tandem parking bays are shown for Tower 2?**
NOT_FOUND

**Q262. What is the difference between Tower 8 Level 02 Floor NSA and Floor NISA?**
2602

**Q290. Is there a Level 13 area row for Tower 8?**
NOT_FOUND

**Q310. What is T7 L2 NISA?**
1665

**Q214. What is the total F&B area?**
NOT_FOUND

**Q174. What is the total balcony area for Tower 7?**
NOT_FOUND

**Q296. Does the schedule state that Tower 6 Level 02 Floor GFA is 1,032.5 sqm?**
2407

**Q152. How many 2-bedroom units are shown in the total row for Tower 5?**
NOT_FOUND

**Q328. What are the six main area metrics shown for individual towers?**
NOT_FOUND

**Q037. What is Tower 8 Level 12 Floor GFA?**
NOT_FOUND

**Q190. What is the total Floor BUA for Tower 8?**
NOT_FOUND

**Q200. What is the GF Podium Floor BUA?**
NOT_FOUND

**Q197. How many standard parking bays are shown for Tower 8?**
NOT_FOUND

**Q169. How many standard parking bays are shown for Tower 6?**
NOT_FOUND

**Q307. What is Tower 6 Level 2 BUA?**
2615

**Q160. What is the total balcony area for Tower 6?**
NOT_FOUND

**Q041. What is Tower 5 Level 02 Floor NISA?**
2247

**Q065. What is Tower 3 Level 02 NSA/GA efficiency?**
85.6%

**Q014. What is Tower 6 Level 02 Floor BUA?**
2615

**Q067. What is Tower 3 Level 09 Floor GFA?**
NOT_FOUND

**Q028. What is Tower 7 Level 11 Floor BUA?**
NOT_FOUND

**Q019. What is Tower 7 Level 02 Floor GFA?**
2054

**Q271. What is Tower 7 Level 02 NSA/GFA when calculated from 1,779 and 2,054?**
86.6%

**Q010. What is Tower 6 Level 02 Floor GA?**
2446

**Q272. What is Tower 8 Level 02 NSA/GA when calculated from 2,772 and 3,238?**
85.6%

**Q153. How many 3-bedroom units are shown in the total row for Tower 5?**
NOT_FOUND

**Q322. What is T5 L2 GFA?**
2772

**Q268. What is Tower 6 Level 02 NSA/GA when calculated from 2,071 and 2,446?**
84.7%

**Q176. What is the total Floor BUA for Tower 7?**
NOT_FOUND

**Q242. What is the overall efficiency APT NSA/GFA?**
NOT_FOUND

**Q305. What is T6 Level 2 balcony area?**
131

**Q137. How many 1-bedroom units are shown in the total row for Tower 4?**
NOT_FOUND

**Q225. What parking rate is shown for 3 Bed at a Tandem Bay?**
NOT_FOUND

**Q217. Is the total GFA equal to GF Podium GFA plus Basement GFA?**
NOT_FOUND

**Q213. What is the total Retail area?**
NOT_FOUND

**Q171. What is the total Floor GFA for Tower 7?**
NOT_FOUND

**Q320. What is T4 L2 GFA?**
3329

**Q277. What is the simple arithmetic sum of GF Podium and Basement BUA?**
NOT_FOUND

**Q071. What is Tower 2 Level 02 Floor NISA?**
3232

**Q092. What is the total balcony area for Tower 1?**
NOT_FOUND

**Q026. What is Tower 7 Level 02 NSA/GFA efficiency?**
86.6%

**Q053. What is Tower 4 Level 02 Floor NSA?**
2870

**Q267. What is the difference between Tower 1 Level 02 Floor NSA and Floor NISA?**
3232

**Q149. What is the NSA/GA efficiency for Tower 5?**
NOT_FOUND

**Q256. What is Tower 2 Level 02 NSA if calculated as NISA plus balconies?**
3232

**Q292. Is a 5-bedroom unit category listed in the unit matrix?**
NOT_FOUND

**Q187. What is the total Floor NISA for Tower 8?**
NOT_FOUND

**Q240. What is the overall achieved 2-bedroom unit mix percentage?**
NOT_FOUND

**Q124. What is the NSA/GFA efficiency for Tower 3?**
NOT_FOUND

**Q114. What is the total number of residential units for Tower 2?**
NOT_FOUND

**Q265. What is the difference between Tower 3 Level 02 Floor NSA and Floor NISA?**
3002

**Q194. How many 2-bedroom units are shown in the total row for Tower 8?**
NOT_FOUND

**Q287. Is there a Tower 9 in the individual tower area schedule?**
NOT_FOUND

**Q166. How many 2-bedroom units are shown in the total row for Tower 6?**
NOT_FOUND

**Q244. What is the total GF Podium GFA shown in the grand total section?**
NOT_FOUND

**Q132. What is the total balcony area for Tower 4?**
NOT_FOUND

**Q312. What is T8 L2 GFA?**
3229

**Q143. What is the total Floor GFA for Tower 5?**
NOT_FOUND

**Q168. What is the total number of residential units for Tower 6?**
NOT_FOUND

**Q013. What is Tower 6 Level 02 Floor NSA?**
2071

**Q084. What is Tower 1 Level 02 Floor BUA?**
4282

**Q023. What is Tower 7 Level 02 Floor NSA?**
1779

**Q103. What is the total Floor GFA for Tower 2?**
NOT_FOUND

**Q302. What is the gross floor area of T6 on L2?**
NOT_FOUND

**Q068. What is Tower 3 Level 09 Floor BUA?**
NOT_FOUND

**Q327. Which schedule contains the individual tower breakdown area tables?**
NOT_FOUND

**Q125. How many 1-bedroom units are shown in the total row for Tower 3?**
NOT_FOUND

**Q038. What is Tower 8 Level 12 Floor BUA?**
NOT_FOUND

**Q228. Is achieved parking higher than required?**
NOT_FOUND

**Q323. What is T5 L2 BUA?**
2979

**Q093. What is the total Floor NSA for Tower 1?**
NOT_FOUND

**Q332. What is the target 1-bedroom unit mix percentage shown in Schedule 05?**
NOT_FOUND

**Q101. How many standard parking bays are shown for Tower 1?**
NOT_FOUND

**Q216. What is the total Nursery area?**
NOT_FOUND

**Q208. Does the Basement have an F&B area listed?**
NOT_FOUND

**Q253. What is Tower 5 Level 02 NSA if calculated as NISA plus balconies?**
2247

**Q070. What is Tower 2 Level 02 Floor GA?**
4001

**Q102. How many tandem parking bays are shown for Tower 1?**
NOT_FOUND

**Q170. How many tandem parking bays are shown for Tower 6?**
NOT_FOUND

**Q045. What is Tower 5 Level 02 NSA/GA efficiency?**
85.8%

**Q175. What is the total Floor NSA for Tower 7?**
NOT_FOUND

**Q001. What project does this area schedule belong to?**
NOT_FOUND

**Q209. Does the Basement have a Supermarket area listed?**
NOT_FOUND

**Q069. What is Tower 2 Level 02 Floor GFA?**
3952

**Q159. What is the total Floor NISA for Tower 6?**
NOT_FOUND

**Q082. What is Tower 1 Level 02 Balconies area?**
206

**Q140. What is the total number of residential units for Tower 4?**
NOT_FOUND

**Q113. How many 3-bedroom units are shown in the total row for Tower 2?**
NOT_FOUND

**Q248. What is the nursery GFA shown in the ground floor/basement section?**
NOT_FOUND

**Q178. What is the NSA/GFA efficiency for Tower 7?**
NOT_FOUND

**Q099. How many 3-bedroom units are shown in the total row for Tower 1?**
NOT_FOUND

**Q215. What is the total Supermarket area?**
NOT_FOUND

**Q236. What percentage of required parking is achieved?**
NOT_FOUND

**Q189. What is the total Floor NSA for Tower 8?**
NOT_FOUND

**Q091. What is the total Floor NISA for Tower 1?**
NOT_FOUND

**Q027. What is Tower 7 Level 11 Floor GFA?**
NOT_FOUND

**Q040. What is Tower 5 Level 02 Floor GA?**
2790

**Q058. What is Tower 4 Level 10 Floor BUA?**
NOT_FOUND

**Q055. What is Tower 4 Level 02 NSA/GA efficiency?**
84.6%

**Q303. Give me T6 L2 GA.**
2446

**Q052. What is Tower 4 Level 02 Balconies area?**
180

**Q016. What is Tower 6 Level 02 NSA/GFA efficiency?**
86.0%

**Q066. What is Tower 3 Level 02 NSA/GFA efficiency?**
86.8%

**Q044. What is Tower 5 Level 02 Floor BUA?**
2979

**Q004. What is the document date?**
NOT_FOUND